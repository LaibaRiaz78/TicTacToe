document.addEventListener('DOMContentLoaded', () => {
    // Game state
    let board = ['', '', '', '', '', '', '', '', ''];
    let currentPlayer = 'X';
    let gameActive = true;
    let scores = { X: 0, O: 0 };
    let moveHistory = [];
    let vsAI = false;
    let gamesPlayed = 0;
    let movesMade = 0;
    let winStreak = 0;
    let gameStartTime = new Date();
    let timerInterval;
    let moveTimers = { X: 0, O: 0 };
    let currentPlayerTimerStart;

    // Elements
    const cells = document.querySelectorAll('.cell');
    const status = document.getElementById('status');
    const restartBtn = document.getElementById('restart');
    const toggleAIBtn = document.getElementById('toggle-ai');
    const playerXElem = document.querySelector('.player-x');
    const playerOElem = document.querySelector('.player-o');
    const playerXScore = playerXElem.querySelector('.score');
    const playerOScore = playerOElem.querySelector('.score');
    const historyList = document.getElementById('history-list');
    const gamesPlayedStat = document.querySelectorAll('.stat-value')[0];
    const movesMadeStat = document.querySelectorAll('.stat-value')[1];
    const winStreakStat = document.querySelectorAll('.stat-value')[2];
    const timerDisplay = document.getElementById('timer');

    // Initialize game timer
    startTimer();

    // Winning combinations
    const winningConditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
        [0, 4, 8], [2, 4, 6]             // diagonals
    ];

    // Initialize game
    initGame();

    function initGame() {
        cells.forEach(cell => {
            cell.addEventListener('click', handleCellClick);
            cell.classList.remove('x', 'o', 'winning');

            // Add hover effect with delay to prevent flickering
            cell.addEventListener('mouseenter', function () {
                if (this.textContent === '' && gameActive) {
                    this.style.transform = 'translateY(-3px) scale(1.03)';
                    this.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.12)';
                    this.style.borderColor = '#3498db';
                    this.style.backgroundColor = '#f8fafc';
                }
            });

            cell.addEventListener('mouseleave', function () {
                if (this.textContent === '' && !this.classList.contains('winning')) {
                    this.style.transform = '';
                    this.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.08)';
                    this.style.borderColor = 'transparent';
                    this.style.backgroundColor = 'white';
                }
            });
        });

        restartBtn.addEventListener('click', restartGame);
        toggleAIBtn.addEventListener('click', toggleAI);

        // Add button hover effects
        const buttons = document.querySelectorAll('button');
        buttons.forEach(button => {
            button.addEventListener('mouseenter', function () {
                this.style.transform = 'translateY(-3px) scale(1.05)';
            });

            button.addEventListener('mouseleave', function () {
                if (!this.classList.contains('btn-pulse')) {
                    this.style.transform = '';
                }
            });
        });

        updateStatus();
    }

    function handleCellClick(e) {
        const cell = e.target;
        const index = parseInt(cell.getAttribute('data-index'));

        // Check if cell is already taken or game is not active
        if (board[index] !== '' || !gameActive) return;

        // Add visual feedback
        cell.classList.add('highlight');
        setTimeout(() => cell.classList.remove('highlight'), 1000);

        // Update player timer
        updatePlayerTimer();

        // Make move
        makeMove(index, currentPlayer);
        movesMade++;
        movesMadeStat.textContent = movesMade;

        // Check for win or draw
        if (checkWin()) {
            handleWin();
            return;
        }

        if (checkDraw()) {
            handleDraw();
            return;
        }

        // Switch player
        switchPlayer();

        // AI move if enabled
        if (vsAI && gameActive && currentPlayer === 'O') {
            setTimeout(makeAIMove, 600);
        }
    }

    function makeMove(index, player) {
        board[index] = player;
        // Add the class to show X or O
        cells[index].classList.add(player.toLowerCase());
        moveHistory.push([...board]);

        // Add to history
        addHistoryItem(`Player ${player} placed at position ${index}`, 'move');
    }

    function makeAIMove() {
        // Update player timer
        updatePlayerTimer();

        // Simple AI - try to win, then block, then take center, then random
        let move = -1;

        // Try to win
        move = findWinningMove('O');

        // Block player if can't win
        if (move === -1) {
            move = findWinningMove('X');
        }

        // Take center if available
        if (move === -1 && board[4] === '') {
            move = 4;
        }

        // Take a random available cell
        if (move === -1) {
            const availableCells = [];
            for (let i = 0; i < 9; i++) {
                if (board[i] === '') availableCells.push(i);
            }
            move = availableCells[Math.floor(Math.random() * availableCells.length)];
        }

        // Add visual feedback for AI move
        cells[move].classList.add('highlight');
        setTimeout(() => cells[move].classList.remove('highlight'), 1000);

        makeMove(move, 'O');
        movesMade++;
        movesMadeStat.textContent = movesMade;

        if (checkWin()) {
            handleWin();
            return;
        }

        if (checkDraw()) {
            handleDraw();
            return;
        }

        switchPlayer();
    }

    function switchPlayer() {
        // Update timer for the current player
        updatePlayerTimer();

        // Switch to the other player
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';

        // Start timer for the new current player
        currentPlayerTimerStart = new Date();

        updateStatus();
    }

    function findWinningMove(player) {
        for (let condition of winningConditions) {
            const [a, b, c] = condition;
            const cells = [board[a], board[b], board[c]];

            // Count player marks and empty cells
            const playerCount = cells.filter(cell => cell === player).length;
            const emptyCount = cells.filter(cell => cell === '').length;

            // If there are two player marks and one empty, return the empty cell
            if (playerCount === 2 && emptyCount === 1) {
                if (board[a] === '') return a;
                if (board[b] === '') return b;
                if (board[c] === '') return c;
            }
        }
        return -1;
    }

    function checkWin() {
        for (let condition of winningConditions) {
            const [a, b, c] = condition;
            if (board[a] && board[a] === board[b] && board[a] === board[c]) {
                // Highlight winning cells
                cells[a].classList.add('winning');
                cells[b].classList.add('winning');
                cells[c].classList.add('winning');
                return true;
            }
        }
        return false;
    }

    function checkDraw() {
        return !board.includes('') && !checkWin();
    }

    function handleWin() {
        gameActive = false;
        scores[currentPlayer]++;
        updateScores();
        gamesPlayed++;
        winStreak++;
        gamesPlayedStat.textContent = gamesPlayed;
        winStreakStat.textContent = winStreak;

        status.textContent = `Player ${currentPlayer} wins!`;
        addHistoryItem(`Player ${currentPlayer} won the game`, 'win');

        // Update timer one last time
        updatePlayerTimer();
        stopTimer();

        // Animate status message
        status.classList.add('highlight');
        setTimeout(() => status.classList.remove('highlight'), 1000);
    }

    function handleDraw() {
        gameActive = false;
        gamesPlayed++;
        winStreak = 0;
        gamesPlayedStat.textContent = gamesPlayed;
        winStreakStat.textContent = winStreak;

        status.textContent = "It's a draw!";
        addHistoryItem("Game ended in a draw", 'draw');

        // Update timer one last time
        updatePlayerTimer();
        stopTimer();

        // Animate status message
        status.classList.add('highlight');
        setTimeout(() => status.classList.remove('highlight'), 1000);
    }

    function restartGame() {
        board = ['', '', '', '', '', '', '', '', ''];
        gameActive = true;
        currentPlayer = 'X';
        moveHistory = [];
        movesMade = 0;
        movesMadeStat.textContent = movesMade;
        gameStartTime = new Date();
        moveTimers = { X: 0, O: 0 };
        currentPlayerTimerStart = new Date();

        cells.forEach(cell => {
            cell.classList.remove('x', 'o', 'winning');
            cell.style.transform = '';
            cell.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.08)';
            cell.style.borderColor = 'transparent';
            cell.style.backgroundColor = 'white';
        });

        // Restart the timer
        stopTimer();
        startTimer();

        updateStatus();
        addHistoryItem("New game started", 'move');

        // Animate the restart button
        restartBtn.classList.add('highlight');
        setTimeout(() => restartBtn.classList.remove('highlight'), 1000);
    }

    function toggleAI() {
        vsAI = !vsAI;
        toggleAIBtn.innerHTML = vsAI ?
            '<i class="fas fa-user"></i> vs Human' :
            '<i class="fas fa-robot"></i> Play vs AI';

        addHistoryItem(`AI mode ${vsAI ? 'enabled' : 'disabled'}`, 'move');

        // Animate the AI button
        toggleAIBtn.classList.add('highlight');
        setTimeout(() => toggleAIBtn.classList.remove('highlight'), 1000);

        restartGame();
    }

    function updateStatus() {
        status.textContent = `Player ${currentPlayer}'s turn`;

        // Update active player indicator
        if (currentPlayer === 'X') {
            playerXElem.classList.add('active');
            playerOElem.classList.remove('active');
        } else {
            playerOElem.classList.add('active');
            playerXElem.classList.remove('active');
        }

        // Start timer for the current player
        currentPlayerTimerStart = new Date();
    }

    function updateScores() {
        playerXScore.textContent = scores.X;
        playerOScore.textContent = scores.O;

        // Animate score update
        if (currentPlayer === 'X') {
            playerXScore.classList.add('highlight');
            setTimeout(() => playerXScore.classList.remove('highlight'), 1000);
        } else {
            playerOScore.classList.add('highlight');
            setTimeout(() => playerOScore.classList.remove('highlight'), 1000);
        }
    }

    function startTimer() {
        gameStartTime = new Date();
        currentPlayerTimerStart = new Date();

        timerInterval = setInterval(() => {
            const now = new Date();
            const totalDiff = Math.floor((now - gameStartTime) / 1000);
            const minutes = Math.floor(totalDiff / 60);
            const seconds = totalDiff % 60;

            // Update timer display
            timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            // Add warning class if game is taking a while
            if (totalDiff > 60) {
                timerDisplay.classList.add('timer-warning');
            } else {
                timerDisplay.classList.remove('timer-warning');
            }

            // Update current player timer
            updatePlayerTimer();
        }, 1000);
    }

    function stopTimer() {
        clearInterval(timerInterval);
    }

    function updatePlayerTimer() {
        if (currentPlayerTimerStart) {
            const now = new Date();
            const diff = Math.floor((now - currentPlayerTimerStart) / 1000);
            moveTimers[currentPlayer] += diff;
            currentPlayerTimerStart = now;
        }
    }

    function addHistoryItem(text, type) {
        const item = document.createElement('div');
        item.className = 'history-item';

        const icon = document.createElement('div');
        icon.className = `history-icon history-${type}`;

        if (type === 'move') {
            icon.innerHTML = '<i class="fas fa-arrow-right"></i>';
        } else if (type === 'win') {
            icon.innerHTML = '<i class="fas fa-trophy"></i>';
        } else {
            icon.innerHTML = '<i class="fas fa-handshake"></i>';
        }

        item.appendChild(icon);
        item.appendChild(document.createTextNode(text));

        // Remove existing history items if there are more than 6
        const historyItems = historyList.querySelectorAll('.history-item');
        if (historyItems.length >= 6) {
            historyList.removeChild(historyItems[0]);
        }

        historyList.appendChild(item);
        historyList.scrollTop = historyList.scrollHeight;

        // Animate new history item
        item.classList.add('highlight');
        setTimeout(() => item.classList.remove('highlight'), 1000);
    }
});